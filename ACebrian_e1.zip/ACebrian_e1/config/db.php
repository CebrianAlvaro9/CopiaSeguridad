<?php
#config/db.php
namespace Config;

const DSN = 'mysql:dbname=mvc;host=localhost';
const USER = 'root';

